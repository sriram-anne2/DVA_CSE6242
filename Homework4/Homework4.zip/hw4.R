#GT Username: sanne31@gatech.edu
#PRE WORK
#ALL CODE WRITTEN BELOW IS FROM MY OWN SUBMISSION FOR HOMEWORK 3
#ATTACHED HW3.R FOR REFERENCE
setwd("F:/GA-Tech/Summer 2018/CSE6242/Homework4/mnist")
#Reading csv files separately into their own dataframes
if((file.exists("mnist_test.csv")) && (file.exists("mnist_train.csv"))) {
  tr_set <- read.csv(file = "mnist_train.csv", header = FALSE)
  te_set <- read.csv(file = "mnist_test.csv", header = FALSE)
}
#transposing training and testing datasets
tr_set <- as.data.frame(t(tr_set))
te_set <- as.data.frame(t(te_set))

names(tr_set)[785] <- "Label"
names(te_set)[785] <- "Label"

#partitioning training set based on given classification
train_0_1 <- tr_set[(tr_set$Label == 0) | (tr_set$Label == 1),]
train_3_5 <- tr_set[(tr_set$Label == 3) | (tr_set$Label == 5),]

#partitioning testing set based on given classification
test_0_1 <- te_set[(te_set$Label == 0) | (te_set$Label == 1),]
test_3_5 <- te_set[(te_set$Label == 3) | (te_set$Label == 5),]

dim(train_0_1) #12,665 samples
dim(train_3_5) #11,552 samples

dim(test_0_1) #2,115 samples
dim(test_3_5) #1,902 samples

#sampling done in below task
#further data preprocessing also done below
#other references listed
#https://datascienceplus.com/perform-logistic-regression-in-r/

#1. Implementation
#https://www.r-bloggers.com/logistic-regression-with-r-step-by-step-implementation-part-2/
#http://diffsharp.github.io/DiffSharp/examples-gradientdescent.html
#http://ethen8181.github.io/machine-learning/linear_regression/linear_regession.html

sigmoid_func <- function(x)
{
  s <- 1/(1 + exp(-x))
  return(s)
}

grad <- function(x,y,theta)
{
  val <- sigmoid_func(as.matrix(x) %*% theta)
  grad <- ((1/nrow(x)) * (t(x)%*%as.matrix((val) - y)))
  return(grad)
}

grad_func <- function(x,y,theta,count,alpha,e)
{
  tmp <- theta
  for (i in 1:count) 
  {
    tmp <- tmp - alpha * grad(x,y,theta)
    if(abs(norm(as.matrix(tmp)) - norm(as.matrix(theta))) < e)
    {
      return(tmp)
    }
    theta <- tmp
  }
  return(tmp)
}

train <- function(data, labels, alpha)
{
  theta <- rep(0,ncol(data))
  #taking 100 iterations
  theta <- grad_func(data,labels,theta,100,alpha,0.001)
  #initial value 0.001
  return(theta)
}
predict <- function(theta, data)
{
  return(sigmoid_func(as.matrix(data) %*% theta))
}

#sampling dataset obtained in prework - taking 50% subset 
train_0_1 <- train_0_1[sample(nrow(train_0_1), nrow(train_0_1)*0.5),]
train_3_5 <- train_3_5[sample(nrow(train_3_5), nrow(train_3_5)*0.5),]
test_0_1 <- test_0_1[sample(nrow(test_0_1), nrow(test_0_1)*0.5),]
test_3_5 <- test_3_5[sample(nrow(test_3_5), nrow(test_3_5)*0.5),]

#new sample sizes
dim(train_0_1) #6,332 samples
dim(train_3_5) #5,776 samples

dim(test_0_1) #1,057 samples
dim(test_3_5) #951 samples

#BELOW CODE ALSO COPIED FROM MY OWN IMPLEMENTATION OF HOMEWORK 3

#creating a backup of datasets
tmp_train01 <- train_0_1
tmp_train35 <- train_3_5
tmp_test01 <- test_0_1
tmp_test35 <- test_3_5

#separating true class label from all partitions

true_train01 <- train_0_1$Label
train_0_1$Label <- NULL
true_train35 <- train_3_5$Label
train_3_5$Label <- NULL
true_test01 <- test_0_1$Label
test_0_1$Label <- NULL
true_test35 <- test_3_5$Label
test_3_5$Label <- NULL

#running train on 01 dataset for both training and testing datasets


#2. Modeling
#https://stats.stackexchange.com/questions/65244/how-to-determine-the-accuracy-of-logistic-regression-in-r
#https://www.r-bloggers.com/evaluating-logistic-regression-models/
#https://rpubs.com/jpmurillo/153750

accuracy <- function(labels, labels_pred)
{
  test_pdct <- labels_pred
  #for all predicted true labels less than 0.1 - predicted value would be 0
  test_pdct[test_pdct < 0.1] <- 0 #signifies false
  #and vice versa is also true
  #=> predicted true lables more than 0.1 means that predicted value is correct and would be 1
  test_pdct[test_pdct > 0.1] <- 1 #signifies true

  #acc is the fraction of values that are actually matching
  #up with the true labels
  matching_values <- sum(test_pdct == labels)
  #count <- count(labels)
  acc <- matching_values/length(labels)
  return(acc)
}

model <- function(train_data, train_labels, test_data, test_labels, alpha)
{
  theta <- train(train_data, train_labels, alpha)
  
  tr_pdct <- predict(theta, train_data)
  train_acc <- accuracy(train_labels, tr_pdct)
  
  te_pdct <- predict(theta, test_data)
  test_acc <- accuracy(test_labels, te_pdct)
  
  final_model <- list(theta, train_acc, test_acc)
  return(final_model)
}


#true labels for the testing dataset 
#as well as for the training dataset 
#for class labels 3 and 5
yy35test <- true_test35
yy35test[yy35test == 3] <- 0
yy35test[yy35test == 5] <- 1

yy35train <- true_train35
yy35train[yy35train == 3] <- 0
yy35train[yy35train == 5] <- 1

#training and test accuracies on the trained model for both 0/1 set and 3/5 set
model_vals <- data.frame(matrix(ncol = 5, nrow = 11))
colnames(model_vals) <- c("Variable Learning Rate(s)", 
                          "Training Accuracy (0/1 set)", 
                          "Testing Accuracy (0/1 set)", 
                          "Training Accuracy (3/5 set)", 
                          "Testing Accuracy (3/5 set)")
lrates <- seq(from = 0.1, to = 0.6, by = 0.05)
start_with <- 1
for (j in lrates) 
{
  model_01set <- model(train_0_1, true_train01, test_0_1, true_test01,j)
  model_35set <- model(train_3_5, yy35train, test_3_5, yy35test,j)
  model_vals[start_with,1] <- j
  model_vals[start_with,2] <- model_01set[2]
  model_vals[start_with,3] <- model_01set[3]
  model_vals[start_with,4] <- model_35set[2]
  model_vals[start_with,5] <- model_35set[3]
  start_with <- start_with + 1
}
#https://stackoverflow.com/questions/22906804/matrix-expression-causes-error-requires-numeric-complex-matrix-vector-arguments
names(model_vals) <- c("variable_learning_rate", "train_accuracy_01", "test_accuracy_01", "train_accuracy_35", "test_accuracy_35")
library(ggplot2)
ggplot(data = model_vals, 
       aes(x = variable_learning_rate, y = train_accuracy_01)) +
       geom_line() + scale_y_log10()

ggplot(data = model_vals, 
       aes(x = variable_learning_rate, y = test_accuracy_01)) +
  geom_line() + scale_y_log10()

ggplot(data = model_vals, 
       aes(x = variable_learning_rate, y = train_accuracy_35)) +
  geom_line() + scale_y_log10()

ggplot(data = model_vals, 
       aes(x = variable_learning_rate, y = test_accuracy_35)) +
  geom_line() + scale_y_log10()

#3. Learning Curves

#partitioning training set based on given classification
new_train_0_1 <- tr_set[(tr_set$Label == 0) | (tr_set$Label == 1),]
new_train_3_5 <- tr_set[(tr_set$Label == 3) | (tr_set$Label == 5),]

#partitioning testing set based on given classification
new_test_0_1 <- te_set[(te_set$Label == 0) | (te_set$Label == 1),]
new_test_3_5 <- te_set[(te_set$Label == 3) | (te_set$Label == 5),]


size_var <- data.frame(matrix(ncol = 5, nrow = 10))
colnames(size_var) <- c("percentage_sample_data", "train_accuracy_01", "test_accuracy_01", "train_accuracy_35", "test_accuracy_35")
percents <- seq(from = 0.1, to = 0.55, by = 0.05)
start_with2 <- 1

for (sample in percents) 
{
  #sampling out data based on chosen percentage above
  sized_train_01 <- new_train_0_1[sample(nrow(new_train_0_1), nrow(new_train_0_1)*sample),]
  sized_train_35 <- new_train_3_5[sample(nrow(new_train_3_5), nrow(new_train_3_5)*sample),]
  sized_test_01 <- new_test_0_1[sample(nrow(new_test_0_1), nrow(new_test_0_1)*sample),]
  sized_test_35 <- new_test_3_5[sample(nrow(new_test_3_5), nrow(new_test_3_5)*sample),]
  
  #finding true labels for the sampled datasets
  sized_truetrain01 <- sized_train_01[,784]
  sized_truetrain35 <- sized_train_35[,784]
  sized_truetest01 <- sized_test_01[,784]
  sized_truetest35 <- sized_test_35[,784]
  
  
  sized_yy35test <- sized_truetest35
  sized_yy35test[sized_yy35test == 3] <- 0
  sized_yy35test[sized_yy35test == 5] <- 1
  
  sized_yy35train <- sized_truetrain35
  sized_yy35train[sized_yy35train == 3] <- 0
  sized_yy35train[sized_yy35train == 5] <- 1
  

  
  #training the 2 models
  sizedmodel_01 <- model(sized_train_01, sized_truetrain01, sized_test_01, sized_truetest01, 0.3)
  sizedmodel_35 <- model(sized_train_35, sized_yy35train, sized_test_35, sized_yy35test, 0.3)
  
  size_var[start_with2,1] <- sample
  size_var[start_with2,2] <- sizedmodel_01[2]
  size_var[start_with2,3] <- sizedmodel_01[3]
  size_var[start_with2,4] <- sizedmodel_35[2]
  size_var[start_with2,5] <- sizedmodel_35[3]
  
  start_with2 <- start_with2 + 1
}

ggplot(data = size_var, aes(x = percentage_sample_data, y = train_accuracy_01)) + geom_line() + scale_y_log10()

ggplot(data = size_var, aes(x = percentage_sample_data, y = test_accuracy_01)) + geom_line() + scale_y_log10()

ggplot(data = size_var, aes(x = percentage_sample_data, y = train_accuracy_35)) + geom_line() + scale_y_log10()

ggplot(data = size_var, aes(x = percentage_sample_data, y = test_accuracy_35)) + geom_line() + scale_y_log10()

